# Bank-Management-System

This is a Bank Management System Database Project.



Abstract: The main aim of Bank Management Mini DBMS project is to keep record of customer transactions in the bank. 

We aim to demonstrate the use of create, read, update and delete MySQL operations through this project.

Firstly, employee registration is done in the concern bank branch. 

Branch employee creates customer account in the bank, then customer can credit amount, debit amount and check balance. 

Customer can even use different services like insurance, loan, bill payments etc.




Modules:


Bank Management Mini DBMS Project contains 4 modules:



1.	Account Holder: As the name suggests, a record of customer details.

2.	Transaction: Transactions to be made by the customer (credit amount, debit etc).

3.	Services: Additional services that customer may want like (insurance, loan etc.).

4.	Branch/Employee : Manager/Employee details of the concern bank.




SOFTWARE REQUIREMENTS:



•	Operating system 		: 	Windows XP/7/10.

•	Language		       	:	  Java ( Install JDK 8 version)

•	IDE				          :	  Netbeans 8.2 / Eclipse

•	Database			      :	  MYSQL (Install XAMPP)






Technologies used:



•	JavaFX

•	Mysql



